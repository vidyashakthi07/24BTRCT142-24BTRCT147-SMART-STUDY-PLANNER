// load saved data or create empty
let studyData =
JSON.parse(localStorage.getItem("studyData"))
|| {};

let chart;


// add study hours
function addProgress()
{

let subject =
document.getElementById("subject").value;

let hours =
Number(document.getElementById("hours").value);


if(!hours || hours<=0)
{
alert("Enter valid hours");
return;
}


// store hours
if(!studyData[subject])
studyData[subject]=0;


studyData[subject]+=hours;


// save data
localStorage.setItem(
"studyData",
JSON.stringify(studyData)
);


// update UI
drawChart();

showSuggestion();

}



// draw graph
function drawChart()
{

let subjects =
Object.keys(studyData);

let hours =
Object.values(studyData);


// remove old chart
if(chart)
chart.destroy();


chart = new Chart(
document.getElementById("chart"),
{

type:"bar",

data:
{

labels:subjects,

datasets:
[{

label:"Hours Studied",

data:hours,

backgroundColor:
[
"#4f6ef7",
"#00c9a7",
"#ff6b6b",
"#ffd93d",
"#845ec2",
"#ff9671"
]

}]

},


options:
{

responsive:true,

plugins:
{

legend:
{
display:false
}

}

}

});

}



// show improvement suggestion
function showSuggestion()
{

if(Object.keys(studyData).length==0)
return;


let minSubject =
Object.keys(studyData)
.reduce(
(a,b)=>
studyData[a]<studyData[b]?a:b
);


let maxSubject =
Object.keys(studyData)
.reduce(
(a,b)=>
studyData[a]>studyData[b]?a:b
);


document.getElementById(
"suggestion"
).innerHTML =

"📉 Improve more in <b>"
+ minSubject +
"</b><br><br>"
+
"🏆 Strong subject: <b>"
+ maxSubject +
"</b>";

}



// optional pie chart
function showPieChart()
{

let subjects =
Object.keys(studyData);

let hours =
Object.values(studyData);


if(chart)
chart.destroy();


chart = new Chart(
document.getElementById("chart"),
{

type:"pie",

data:
{

labels:subjects,

datasets:
[{

data:hours,

backgroundColor:
[
"#4f6ef7",
"#00c9a7",
"#ff6b6b",
"#ffd93d",
"#845ec2",
"#ff9671"
]

}]

}

});

}



// load saved graph on page open
window.onload =
function()
{

drawChart();

showSuggestion();

}