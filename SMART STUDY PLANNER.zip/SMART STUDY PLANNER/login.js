import { initializeApp }
from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";

import {
getAuth,
signInWithEmailAndPassword,
createUserWithEmailAndPassword
}
from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";


const firebaseConfig = {
  apiKey: "AIzaSyCvbY0geEw5OyoTrzhLeUwdiVtqRll6mZ8",
  authDomain: "smart-study-planner-be65b.firebaseapp.com",
  databaseURL: "https://smart-study-planner-be65b-default-rtdb.firebaseio.com",
  projectId: "smart-study-planner-be65b",
  storageBucket: "smart-study-planner-be65b.firebasestorage.app",
  messagingSenderId: "653374023963",
  appId: "1:653374023963:web:d5c88cebfffe7fed530bbe",
  measurementId: "G-NQLBYWYCD0"
};


const app = initializeApp(firebaseConfig);

const auth = getAuth(app);



window.signupUser = function(){

let email =
document.getElementById("email").value;

let password =
document.getElementById("password").value;


createUserWithEmailAndPassword(auth,email,password)

.then(()=>{

document.getElementById("msg").innerHTML =
"Account created ✔";

})

.catch((error)=>{

document.getElementById("msg").innerHTML =
error.message;

});

};



window.loginUser = function(){

let email =
document.getElementById("email").value;

let password =
document.getElementById("password").value;


signInWithEmailAndPassword(auth,email,password)

.then(()=>{

document.getElementById("msg").innerHTML =
"Login success ✔";

window.location.href="index.html";

})

.catch((error)=>{

document.getElementById("msg").innerHTML =
error.message;

});

};