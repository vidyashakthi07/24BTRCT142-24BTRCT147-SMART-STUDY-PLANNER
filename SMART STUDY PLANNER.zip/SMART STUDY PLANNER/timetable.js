function saveTimetable()
{

let data =
{

mon: mon.value,

tue: tue.value,

wed: wed.value,

thu: thu.value,

fri: fri.value,

sat: sat.value,

sun: sun.value

};


localStorage.setItem(

"timetable",

JSON.stringify(data)

);


// show in table

pmon.innerText=data.mon || "";

ptue.innerText=data.tue || "";

pwed.innerText=data.wed || "";

pthu.innerText=data.thu || "";

pfri.innerText=data.fri || "";

psat.innerText=data.sat || "";

psun.innerText=data.sun || "";


alert("Timetable saved");

}



window.onload=function()
{

let data =
JSON.parse(

localStorage.getItem("timetable")

);


if(data)
{

mon.value=data.mon || "";

tue.value=data.tue || "";

wed.value=data.wed || "";

thu.value=data.thu || "";

fri.value=data.fri || "";

sat.value=data.sat || "";

sun.value=data.sun || "";


pmon.innerText=data.mon || "";

ptue.innerText=data.tue || "";

pwed.innerText=data.wed || "";

pthu.innerText=data.thu || "";

pfri.innerText=data.fri || "";

psat.innerText=data.sat || "";

psun.innerText=data.sun || "";

}

}



function downloadPDF()
{

let element =

document.getElementById("pdfContent");


let opt =
{

margin:0.3,

filename:"Smart-Study-Timetable.pdf",

image:{type:"jpeg",quality:1},

html2canvas:{scale:2},

jsPDF:
{

unit:"in",

format:"a4",

orientation:"landscape"

}

};


html2pdf()

.set(opt)

.from(element)

.save();

}