// wait until page loads
window.addEventListener("load", function()
{

let loader = document.getElementById("loader");

if(loader)
loader.style.display = "none";

});


// smooth page transition safely
document.querySelectorAll("a").forEach(link =>
{

link.addEventListener("click", function(e)
{

// skip external links
if(!this.href.includes(window.location.hostname))
return;


e.preventDefault();

document.body.style.opacity = "0";

setTimeout(() =>
{

window.location = this.href;

},200);

});

});